package com.hunght.data;

/**
 * Created by Lenovo on 11/7/2016.
 */

public enum MenuLookUpItemKind {
    None,DanhMucDauTu, DanhMucYeuThich, DuLieuMuaBan, ToanCanhThiTruong, ThucHienQuyen, ThongTinDoanhNghiep, Cafef, Vietstock, TinNhanhChungKhoan, DauTuOnline
}
