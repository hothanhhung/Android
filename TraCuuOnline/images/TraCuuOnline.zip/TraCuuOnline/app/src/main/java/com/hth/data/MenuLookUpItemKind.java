package com.hth.data;

/**
 * Created by Lenovo on 11/7/2016.
 */

public enum MenuLookUpItemKind {
    None, TyGiaNgoaiTe, BangGiaVang, GiaXang, LaiSuatNganHang, DuBaoThoiTiet,
    MaBienSo, DauSoDienThoai, BongDa, MaBuuDien, SwiftCode, GiaOto, OtherLookUp
}
