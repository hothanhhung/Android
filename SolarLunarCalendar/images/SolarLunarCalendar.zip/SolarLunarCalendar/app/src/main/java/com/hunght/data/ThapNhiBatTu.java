package com.hunght.data;

/**
 * Created by Lenovo on 4/18/2018.
 */

public class ThapNhiBatTu {
    public static final int SaoGiac = 1;
    public static final int SaoCang = 2;
    public static final int SaoDe = 3;
    public static final int SaoPhong = 4;
    public static final int SaoTaam = 5;
    public static final int SaoVix = 6;
    public static final int SaoCo = 7;
    public static final int SaoDau = 8;
    public static final int SaoNguu = 9;
    public static final int SaoNu = 10;
    public static final int SaoHu = 11;
    public static final int SaoNguy = 12;
    public static final int SaoThat = 13;
    public static final int SaoBich = 14;
    public static final int SaoKhue = 15;
    public static final int SaoLau = 16;
    public static final int SaoVij = 17;
    public static final int SaoMao = 18;
    public static final int SaoTat = 19;
    public static final int SaoChuy = 20;
    public static final int SaoSam = 21;
    public static final int SaoTirnh = 22;
    public static final int SaoQuy = 23;
    public static final int SaoLieu = 24;
    public static final int SaoTinh = 25;
    public static final int SaoTruong = 26;
    public static final int SaoDuc = 27;
    public static final int SaoChuan = 28;
}
